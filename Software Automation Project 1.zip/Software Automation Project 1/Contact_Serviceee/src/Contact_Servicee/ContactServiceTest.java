package Contact_Servicee;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	
	private ContactService contactService;
	@BeforeEach
    public void setUp() {
        // Initialize the ContactService instance before each test
        contactService = new ContactService();
    }

	@Test
    public void testAddContact() {
        // Create a contact to add
        Contact contact = new Contact("ID1275869", "Danny", "Young", "1234567890", "123 awkward st");
	contactService.addContact(contact);
	
	assertNotNull(contactService.findContactById("ID1275869"));
	}
        
}
