package Contact_Servicee;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {
	
	@Test
	public void testContactConstructor() {
        // Test the Contact constructor
        Contact contact = new Contact("ID1275869", "Danny", "Young", "1234567890", "123 awkward st");
        
        // Check if the fields are correctly initialized
        assertEquals("ID1275869", contact.getContactID());
        assertEquals("Danny", contact.getFirstName());
        assertEquals("Young", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 awkward st", contact.getAddress());
        
	}
       
	

}
