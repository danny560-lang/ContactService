package Contact_Servicee;
import java.util.HashMap;
import java.util.Map;

public class ContactService {
	
	private Map<String, Contact> contacts = new HashMap<>();


    // Method to add a new contact
    public void addContact(Contact contact) {
        // Check if a contact with the same ID already exists
        contacts.put(contact.getContactID(), contact);
    }

    // Method to delete a contact by contact ID
    public void deleteContact(String contactID) {
        // Find and remove the contact with the given ID
       contacts.remove(contactID);
    }

    // Method to update contact fields by contact ID
    public void updateContact(Contact updatedContact) {
        contacts . put(updatedContact.getContactID(), updatedContact);
    }

    // Helper method to find a contact by contact ID
    Contact findContactById(String contactID) {
    	
        return contacts.get(contactID);
    }

}
