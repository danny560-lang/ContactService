package appointment;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentServiceTest {
    


    @Test
    public void testAddAppointment() {
    	AppointmentService appointmentService = new AppointmentService();
        // Test data
        Date currentDate = new Date();
        String appointmentID = "Appt001";
        String description = "Sample Appointment";

        // Create an appointment
        Appointment appointment = new Appointment(appointmentID, currentDate, description);

        // Add the appointment to the service
        appointmentService.addAppointment(appointment);

        // Check if the appointment was added successfully
        assertNotNull(appointmentService.findAppointmentByID("Appt001"));
    }

}
