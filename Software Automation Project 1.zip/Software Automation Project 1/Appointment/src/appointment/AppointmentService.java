package appointment;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class AppointmentService {
    private Map<String, Appointment> appointments;

    public AppointmentService() {
        appointments = new HashMap<>();
    }

    // Method to add an appointment
    public void addAppointment(Appointment appointment) {
        // Check if the appointment ID is unique
        appointments.put(appointment.getAppointmentID(), appointment);
    }

    // Method to delete an appointment by appointment ID
    public void deleteAppointment(String appointmentID) {
    	appointments.remove(appointmentID);
        
    }
   

   public void updateAppointment(Appointment updatedappointment){
	   appointments.put(updatedappointment.getAppointmentID(), updatedappointment);
    
   }
   
   public Appointment findAppointmentByID(String appointmentID) {
	   return appointments.get(appointmentID);
   }
   
}


