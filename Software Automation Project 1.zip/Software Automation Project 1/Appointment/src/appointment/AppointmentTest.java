package appointment;
import org.junit.jupiter.api.Test;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {

    @Test
    public void testAppointmentCreation() {
        // Test data
        Date currentDate = new Date();
        String appointmentID = "Appt001";
        String description = "Sample Appointment";

        // Create an appointment
        Appointment appointment = new Appointment(appointmentID, currentDate, description);

        // Test the getters
        assertEquals(appointmentID, appointment.getAppointmentID());
        assertEquals(currentDate, appointment.getAppointmentDate());
        assertEquals(description, appointment.getDescription());
    }
}
