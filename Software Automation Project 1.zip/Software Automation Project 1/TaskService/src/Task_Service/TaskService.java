package Task_Service;
import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks;

    public TaskService() {
        this.tasks = new HashMap<>();
    }

    public void addTask(Task task) {
            tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    public void updateTaskName(Task updatedTask) {
       tasks.put(updatedTask.getTaskId(), updatedTask);
    }
    
    
    public Task findTaskById(String taskId) {
        return tasks.get(taskId);
    }
}