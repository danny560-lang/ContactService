package Task_Service;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("T1", "Task 1", "Description 1");
        taskService.addTask(task);
    
        assertNotNull(taskService.findTaskById("T1"));
    }
}
